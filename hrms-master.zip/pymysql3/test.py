from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtWidgets import QRadioButton
import sys
import pymysql#实现mysql连接
from PyQt5.QtWidgets import QTableWidgetItem
from login import login_Ui_Form
from child import Ui_childWindow

class Login(QMainWindow,login_Ui_Form):
    def __init__(self):
        super(Login, self).__init__()
        self.setupUi(self)
        # self.pushButton_3.clicked.connect(self.close)
        self.buttonGroupuser_type.buttonClicked.connect(self.afterClickButton)
        self.pushButton.clicked.connect(self.login_btn)

    def Open(self):
        self.show()
    def jobseeker_login(self):
        pass
    def afterClickButton(self):
        btn=self.buttonGroupuser_type.checkedButton()
        type=btn.text()
        #print(type)
        return type

    def resign(self):
        print("注册")

    def login(self):
        conn = pymysql.connect(host='localhost',
                                user='root',
                                password='123456',
                                database='myhrms',
                                charset='utf8')
        user = self.textEdit.toPlainText()
        pwd = self.textEdit_2.toPlainText()
        user_type = self.afterClickButton()
        cur = conn.cursor()  # 生成游标对象
        result = None
        if user_type == '求职者':
            sql = "SELECT * FROM user_job_seekers WHERE username = %s AND password = %s "
            params = (user, pwd)
            cur.execute(sql, params)
            result = cur.fetchone()
        elif user_type == '公司HR':
            sql = "SELECT * FROM user_hrs WHERE username = %s AND password = %s "
            params = (user, pwd)
            cur.execute(sql, params)
            result = cur.fetchone()
        elif user_type == '管理员':
            sql = "SELECT * FROM admins WHERE username = %s AND password = %s "
            params = (user, pwd)
            cur.execute(sql, params)
            result = cur.fetchone()

        # if result:
        #     return result
        # else:
        #     #print("账号密码错误")
        #     return None
        cur.close()
        conn.close()
        #print(result)
        return result, user_type

    def login_btn(self):

        result, user_type = self.login()
        if result:
            print("成功登入")
            type = result[1]
            user = result[2]
            #print(type, user)
            #main.Open()
            return type, user
        else:
            #self.textBrowser.setText("登录失败，请重试")
            QMessageBox.warning(self, '错误', '用户名或密码错误！')
            return None

class Child(QMainWindow,Ui_childWindow):#登入后显示的子界面
    def __init__(self):
        super(Child, self).__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.close)
    def Open(self):
        self.show()

if __name__ =="__main__":
    app = QApplication(sys.argv)
    child=Child()
    child.show()
    login=Login()#创建登入界面的对象
    # login.show()
    sys.exit(app.exec_())

