from PyQt5.QtWidgets import QMainWindow, QApplication
from PyQt5.QtWidgets import QMessageBox,QDialog
from PyQt5.QtWidgets import QRadioButton
from father import Ui_MainWindow
from child import Ui_childWindow
from changeseek import change_seeker_Ui_Form
from delseeker import del_seeker_Ui_Form
from checkcv import check_cv_Ui_Form
from re_deliver import re_deliver_Ui_Form
import sys
import pymysql#实现mysql连接
from PyQt5.QtWidgets import QTableWidgetItem
from login import login_Ui_Form
from admin_win import admin_Ui_MainWindow
from resign_first import resigin_first_Ui_Form
from jobseeker_resign import job_seeker_resign_Ui_Form
from company_resign import company_resign_Ui_Form
from my_cv_info2 import my_cv_info_MainWindow
import hashlib
import demo  # 管理员主程序
import demo1 #公司HR主程序
#login_Ui_Form

conn = pymysql.connect(host='localhost',
                     user='root',
                     password='123456',
                     database='myhrms',
                     charset='utf8')
#登入功能----------------------------------------------------------------
class Login(QMainWindow,login_Ui_Form):
    def __init__(self):
        super(Login, self).__init__()
        self.setupUi(self)
        self.buttonGroupuser_type.buttonClicked.connect(self.afterClickButton)#单选按钮设置
        self.pushButton.clicked.connect(self.login_btn)
        self.resign_first_win = None
        self.pushButton_2.clicked.connect(self.Open_resign_first)
        self.main_window =None
        self.jobseeker_change_win=None
        self.admin_main_window = None
        self.company_window=None

    def Open(self):
        self.show()
    def Open_resign_first(self):
        if not self.resign_first_win:
            self.resign_first_win=Resigin_first_Ui_Form()
        self.resign_first_win.Open()


    def jobseeker_login(self):
        pass
    def afterClickButton(self):
        btn=self.buttonGroupuser_type.checkedButton()
        type=btn.text()
        #print(type)
        return type

    def resign(self):
        print("注册")

    def login(self):
        print("login")
        conn = pymysql.connect(host='localhost',
                                user='root',
                                password='123456',
                                database='myhrms',
                                charset='utf8')
        user = self.lineEdit.text()
        pwd = self.lineEdit_2.text()
        user_type = self.afterClickButton()
        print(user_type)
        # 创建一个md5对象
        md5 = hashlib.md5()
        # 更新要加密的内容
        md5.update(pwd.encode('utf-8'))
        # 获取加密后的十六进制字符串
        pwd_md5 = md5.hexdigest()

        cur = conn.cursor()  # 生成游标对象
        result = None
        if user_type == '求职者':
            sql = "SELECT * FROM user_job_seekers WHERE username = %s AND password = %s "
            params = (user,pwd_md5)
            cur.execute(sql, params)
            result = cur.fetchone()
        elif user_type == '公司HR':
            sql = "SELECT * FROM user_hrs WHERE username = %s AND password = %s "
            params = (user,pwd_md5)
            cur.execute(sql, params)
            result = cur.fetchone()
        elif user_type == '管理员':
            sql = "SELECT * FROM admins WHERE username = %s AND password = %s "
            params = (user,pwd_md5)
            cur.execute(sql, params)
            result = cur.fetchone()

        cur.close()
        conn.close()
        return result, user_type

    def login_btn(self):
        try:
            result, user_type = self.login()
            print("login_btn_result", result)
            if result:
                print("成功登入")
                login.hide()
                type = result[1]
                user = result[3]
                print("result",result)
                print("type,user", type, user)
                if type == "求职者":
                    user = result[3]
                    self.Open_jobseeker(user)
                elif type == "公司HR":
                    user = result[2]
                    conn = pymysql.connect(host='localhost',
                                           user='root',
                                           password='123456',
                                           database='myhrms',
                                           charset='utf8')
                    cur = conn.cursor()  # 生成游标对象
                    sql1 = "select * from user_hrs where username =%s "
                    params = (user)
                    cur.execute(sql1, params)
                    data = cur.fetchall()  # 通过fetchall方法获得数据
                    stu = data[0][6]
                    print("公司HR",data[0][6])
                    # 打开公司HR界面
                    if stu ==1:
                        print("公司HR登入")
                        self.Open_company(user)
                    else:
                        print("管理员还未同意账号登入")
                        QMessageBox.warning(self, '错误', '管理员还未同意账号登入')

                elif type == "管理员":  # 打开管理员界面
                    self.Open_admin()
                    print("管理员登入")
                return type, user
            else:
                # self.textBrowser.setText("登录失败，请重试")
                QMessageBox.warning(self, '错误', '用户名或密码错误！')
                return None
        except Exception as e:
            print("登录失败，错误信息为：", e)
            QMessageBox.warning(self, '错误', '登录失败，请重试！')
            return None

#----------------------------------------------------------------
    def Open_jobseeker(self,user):
        if not self.main_window:  # 如果 Main()对象不存在，则创建它
            self.main_window = Main(user) # 创建 求职者界面
            print("Open_jobseeker",user)
        self.main_window.Open()  # 调用 求职者界面的 Open 方法
#----------------------------------------------------------------
    def Open_admin(self):
        if not self.admin_main_window:  # 如果 Main()对象不存在，则创建它
            self.admin_main_window= demo.admin_Main()# 创建 求职者界面
            print("Open_admin")
        self.admin_main_window. Open()  # 调用 求职者界面的 Open 方法
#----------------------------------------------------------------
    def Open_company(self,user):
        if not self.company_window:  # 如果 Main()对象不存在，则创建它
            self.company_window = demo1.DemoUi(user) # 创建 求职者界面
            print("Open_company",user)
        self.company_window.Open() # 调用 求职者界面的 Open 方法
#注册功能----------------------------------------------------------------
class Resigin_first_Ui_Form(QMainWindow,resigin_first_Ui_Form):#注册的第一个窗口
    def __init__(self):
        super(Resigin_first_Ui_Form, self).__init__()
        self.setupUi(self)
        self.pushButton_3.clicked.connect(self.close)
        self.job_seeker_resigin_win=None
        self.company_resigin_win=None
        self.pushButton.clicked.connect(self.Open_job_seeker_resigin)
        self.pushButton_2.clicked.connect(self.Open_company_resigin)


    def Open(self):
        self.show()

    def Open_job_seeker_resigin(self):
        if not self.job_seeker_resigin_win:
            self.job_seeker_resigin_win=Job_seeker_resign()
        self.job_seeker_resigin_win.Open()

    def Open_company_resigin(self):
        if not self.company_resigin_win:
            self.company_resigin_win=Company_resign()
        self.company_resigin_win.Open()


class Job_seeker_resign(QMainWindow,job_seeker_resign_Ui_Form):
    def __init__(self):
        super(Job_seeker_resign, self).__init__()
        self.setupUi(self)
        self.pushButton_2.clicked.connect(self.close)
        self.pushButton.clicked.connect(self.job_seeker_resign)
    def Open(self):
        self.show()
    def job_seeker_resign(self):
        print("resign clicked!")
        user = self.textEdit.toPlainText()
        pwd = self.textEdit_2.toPlainText()
        # 创建一个md5对象
        md5 = hashlib.md5()
        # 更新要加密的内容
        md5.update(pwd.encode('utf-8'))
        # 获取加密后的十六进制字符串
        pwd_md5 = md5.hexdigest()
        # 初始化插入结果为False
        result = False

        job_seeker_name=self.textEdit_3.toPlainText()

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        # 检查参数是否为空
        if not user or not pwd or not job_seeker_name:
            print('输入的值不能为空！')
            # QMessageBox.warning(self, '警告', '输入的参数不能为空！', parent=self)
            QMessageBox.warning(self, '错误', '输入的值不能为空！')
            cur.close()
            conn.close()  # 关闭游标和数据库连接
            return

        # 定义更新语句和参数
        sql1 = "select * from user_job_seekers where username =%s "
        params = (user)
        cur.execute(sql1, params)
        data = cur.fetchall()  # 通过fetchall方法获得数据
        if(len(data)>0):
            print("用户名存在,请重新输入数据")
            QMessageBox.warning(self, '错误', '用户名存在,请重新输入数据！')
        else:
            sql2="INSERT INTO user_job_seekers (id,type, job_seeker_name, username, password) VALUES(NULL,'求职者',%s,%s,%s);"
            params2 = (job_seeker_name,user,pwd_md5)
            try:
                # 执行更新操作
                cur.execute(sql2, params2)
                print("成功注册！")
                QMessageBox.information(self, '注册提示', '成功注册！')
                # 提交事务
                conn.commit()

            except Exception as e:
                conn.rollback()
                print('注册失败：', e)
                QMessageBox.warning(self, '警告', '修改失败！')
            finally:
                # 关闭游标和数据库连接
                cur.close()
                conn.close()

class Company_resign(QMainWindow,company_resign_Ui_Form):
    def __init__(self):
        super(Company_resign, self).__init__()
        self.setupUi(self)
        self.pushButton_2.clicked.connect(self.close)
        self.pushButton.clicked.connect(self.resign_company)
    def Open(self):
        self.show()

    def resign_company(self):
        print("resign_company resign clicked!")
        user = self.textEdit.toPlainText()
        pwd = self.textEdit_2.toPlainText()
        company_name=self.textEdit_3.toPlainText()
        company_type=self.textEdit_4.toPlainText()
        # 创建一个md5对象
        md5 = hashlib.md5()
        # 更新要加密的内容
        md5.update(pwd.encode('utf-8'))
        # 获取加密后的十六进制字符串
        pwd_md5 = md5.hexdigest()


        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        # 检查参数是否为空
        if not user or not pwd or not company_name or not company_type:
            print('输入的值不能为空！')
            # QMessageBox.warning(self, '警告', '输入的参数不能为空！', parent=self)
            QMessageBox.warning(self, '错误', '输入的值不能为空！')
            cur.close()
            conn.close()  # 关闭游标和数据库连接
            return
        # 定义更新语句和参数
        sql1 = "select * from user_hrs where username =%s "
        params = (user)
        cur.execute(sql1, params)
        data = cur.fetchall()  # 通过fetchall方法获得数据
        if(len(data)>0):
            print("用户名存在,请重新输入数据")
            QMessageBox.warning(self, '错误', '用户名存在,请重新输入数据！')
        else:
            sql2="INSERT INTO user_hrs (id, type, username, password, company_name,company_type, status) VALUES(NULL,'公司HR',%s,%s,%s,%s,0);"
            params2 = (user,pwd_md5,company_name,company_type)
            try:
                # 执行更新操作
                cur.execute(sql2, params2)
                print("成功注册！")
                QMessageBox.information(self, '注册提示', '成功注册！')
                # 提交事务
                conn.commit()

            except Exception as e:
                conn.rollback()
                print('注册失败：', e)
                QMessageBox.warning(self, '警告', '修改失败！')
            finally:
                # 关闭游标和数据库连接
                cur.close()
                conn.close()
#求职者界面部分--------------------------------------------------------
class Main(QMainWindow,Ui_MainWindow):#求职者界面设置
    def __init__(self,user):
        super(Main, self).__init__()
        self.user = user
        self.setupUi(self)
        self.pushButton_6.clicked.connect(self.showcompany_se) #查询所有公司的信息
        self.pushButton_5.clicked.connect(self.showrecruit)
        self.child_window = None  # 创建成员变量来保存 child_window 对象的引用
        self.jobseeker_change_win=None# 创建成员变量来保存 jobseeker_change_win对象的引用
        self.jobseeker_del_win=None# 创建成员变量来保存 jobseeker_del_win对象的引用
        self.check_cv_jobseeker_win=None# 创建成员变量来保存 check_cv_jobseeker_win对象的引用
        self.re_deliver_win=None
        self.action_3.triggered.connect(self.Open_jobseeker_change)#菜单上按键连接的事件，展示个人信息
        self.my_cv_info_win=None
        self.action_5.triggered.connect(self.Open_my_cv_info_win)
        self.action_4.triggered.connect(self.Open_re_deliver_win)#菜单上投递简历
        welcome_text="欢迎求职者 " + user
        self.label.setText(welcome_text)

    # def showContnt(self):
    #     print("Button clicked")
    #     self.showAllData()

    def Open(self):
        self.show()
    def open_child_window(self):
        if not self.child_window:  # 如果 Child 对象不存在，则创建它
            self.child_window = Child()  # 创建 Child 对象
        self.child_window.Open()  # 调用 Child 的 Open 方法

    def Open_jobseeker_change(self,user):#求职者信息修改
        if not self.jobseeker_change_win:
            self.jobseeker_change_win=Ch_jobseeker(self.user)
        self.jobseeker_change_win.Open()

    def Open_jobseeker_del(self,user):#打开删除简历状态子窗口
        if not self.jobseeker_del_win:
            self.jobseeker_del_win=Del_seeker_Ui_Form(self.user)
        self.jobseeker_del_win.Open()

    def Open_check_cv_jobseeker(self,user):#打开查看简历状态子窗口
        if not self.check_cv_jobseeker_win:
            self.check_cv_jobseeker_win=Check_cv_Ui_Form(self.user)
        self.check_cv_jobseeker_win.Open()
    #Re_deliver(QMainWindow,re_deliver_Ui_Form):#简历投递功能
    def Open_re_deliver_win(self,user):
        if not self.re_deliver_win:
            self.re_deliver_win=Re_deliver(self.user)
        self.re_deliver_win.Open()
    #My_cv_info(QMainWindow,my_cv_info_MainWindow)
    def Open_my_cv_info_win(self,user):
        if not self.my_cv_info_win:
            self.my_cv_info_win=My_cv_info(self.user)
        self.my_cv_info_win.Open()

    def showCompany_recu(self):#显示公司招聘代码
        # 重置
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(7)
        # 设置表头，这里为了演示，仅仅显示7列数据
        self.tableWidget.setHorizontalHeaderLabels(['公司编号', '岗位名称', '公司名称', '地址', '电话', '薪资', '人数'])
        try:
            conn = pymysql.connect(host='localhost',
                                   user='root',
                                   password='123456',
                                   database='myhrms',
                                   charset='utf8')
            cur = conn.cursor()  # 生成游标对象
            sql = "select * from company "  # SQL语句
            cur.execute(sql)  # 执行SQL语句
            data = cur.fetchall()  # 通过fetchall方法获得数据

            x = 0
            for i in data:
                y = 0
                curRow = self.tableWidget.rowCount()  # 获取当前行
                self.tableWidget.insertRow(curRow)  # 插入一行
                for j in i:
                    self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                    y = y + 1
                x = x + 1
            cur.close()  # 关闭游标
            conn.close()  # 关闭连接
        except Exception as e:
            QMessageBox.warning(self, "错误", "数据库连接失败，请检查数据库配置和网络连接！\n错误信息：" + str(e))


    def showcompanyContents(self):#显示公司招聘代码的按钮连接代码
        print("Button clicked")
        self.showCompany_recu()

    def showCompanyInformation(self):#显示公司信息的代码
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(6)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['公司编号', '公司名称', '公司类型', '地址', '电话', '邮箱'])

        try:
            conn = pymysql.connect(host='localhost',
                                   user='root',
                                   password='123456',
                                   database='myhrms',
                                   charset='utf8')
            cur = conn.cursor()  # 生成游标对象
            sql = "select * from com_infor "  # SQL语句
            cur.execute(sql)  # 执行SQL语句
            data = cur.fetchall()  # 通过fetchall方法获得数据
            x = 0
            for i in data:
                y = 0
                curRow = self.tableWidget.rowCount()  # 获取当前行
                self.tableWidget.insertRow(curRow)  # 插入一行
                for j in i:
                    self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                    y = y + 1
                x = x + 1

            cur.close()  # 关闭游标
            conn.close()  # 关闭连接
        except Exception as e:
            QMessageBox.warning(self, "错误", "数据库连接失败，请检查数据库配置和网络连接！\n错误信息：" + str(e))


    def showcompany_se(self):#显示公司信息的按钮代码
        print("Button clicked")
        self.showCompanyInformation()


    def showRecruit(self):
        # 重置
        print("showRecruit clicked")
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(8)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(
            ['公司ID', '公司类型', '公司名称', '岗位名称', '岗位要求', '工作职责', '薪资', '工作地点'])

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select c_id, company_type,company, position,position_require,job_duty,money,job_place from recruit "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接

    def showrecruit(self):
        print("showrecruit clicked")
        #self.statisticsButton.setHidden(True)  # 隐藏按钮
        self.showRecruit()

#修改用户信息，更新，的窗口--------------------------------------------------------
class Ch_jobseeker(QMainWindow,change_seeker_Ui_Form):#修改用户信息，更新，的窗口
    def __init__(self,user):
        super(Ch_jobseeker,self).__init__()
        self.user = user
        self.setupUi(self)
        self.pushButton_2.clicked.connect(self.close)
        self.pushButton.clicked.connect(self.update)
        self.buttonGroupSex.buttonClicked.connect(self.afterClickButton)#当按钮组其中一个按键被选中时，触发afterClickButton函数
        self.showchange_name(user)
        self.pushButton_3.clicked.connect(self.show_or_massage)
        self.pushButton_4.clicked.connect(self.add_personal_info2)
        self.jobseeker_del_win=None
        self.pushButton_5.clicked.connect(self.Open_jobseeker_del)

    def afterClickButton(self):#单选按键的触发
        btn=self.buttonGroupSex.checkedButton()
        sex=btn.text()
        return sex
        #print(btn.text())
    def showchange_name(self, user):
        self.user=user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT job_seeker_name FROM `user_job_seekers` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        name=data[0]
        self.label_11.setText(name)
        self.label_13.setText(user)
        print(user, name)
        return user,name

    def Open_jobseeker_del(self,user):#打开删除简历子窗口
        if not self.jobseeker_del_win:
            self.jobseeker_del_win=Del_seeker_Ui_Form(self.user)
        self.jobseeker_del_win.Open()


    def Open(self):
        self.show()

    def add_personal_info2(self):
        print("update clicked!")
        user, name = self.showchange_name(self.user)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sex = self.afterClickButton()
        email = self.textEdit_3.toPlainText()
        phone = str(self.textEdit_10.toPlainText())
        address = self.textEdit_4.toPlainText()
        education = self.textEdit_5.toPlainText()
        graduate_institutions = self.textEdit_6.toPlainText()
        work_experience = self.textEdit_7.toPlainText()
        skills = self.textEdit_8.toPlainText()
        intention = self.textEdit_9.toPlainText()
        print("name", name)
        print("sex", sex)
        print("email", email)
        print("phone", phone)
        print("address", address)
        print("education", education)
        print("graduate_institutions", graduate_institutions)
        print("work_experience", work_experience)
        print("skills", skills)
        print("intention", intention)

        if not all([name, sex, email, phone, address, education, graduate_institutions, work_experience, skills,
                    intention]):
            print("插入失败，参数不能为空！")
            QMessageBox.warning(self, '错误', '输入的值不能为空！')
        else:
            try:
                sql = "INSERT INTO jobseeker (id, name, sex, email, phone, address, education, graduate_institutions, work_experience, skills, intention) " \
                      "VALUES (NULL, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                params = (
                    name, sex, email, phone, address, education, graduate_institutions, work_experience, skills,
                    intention)
                cur.execute(sql, params)

                id = cur.lastrowid
                print("插入成功，自动生成的主键值为：", id)
                QMessageBox.information(self, '添加信息', '成功添加信息！')

                conn.commit()
            except Exception as e:
                print("插入失败，错误信息为：", e)
                QMessageBox.warning(self, '错误', '插入失败')
                conn.rollback()  # 发生异常时回滚事务
        cur.close()
        conn.close()


    def add_personal_info(self):
        print("update clicked!")
        user, name = self.showchange_name(self.user)
        print(user, name)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sex = self.afterClickButton()
        email = self.textEdit_3.toPlainText()
        phone = self.textEdit_10.toPlainText()
        addr = self.textEdit_4.toPlainText()
        xueli = self.textEdit_5.toPlainText()
        edu = self.textEdit_6.toPlainText()
        exper = self.textEdit_7.toPlainText()
        skill = self.textEdit_8.toPlainText()
        inten = self.textEdit_9.toPlainText()

        sql1="SELECT * from jobseeker where name = %s"
        params1=(name,)
        cur.execute(sql1, params1)
        data1 = cur.fetchone()
        if data1:
            print("用户信息已经存在，无需要添加")
            QMessageBox.information(self, '提示', '用户信息已经存在，无需要添加')
            cur.close()
            conn.close()
            return
        else:
            # 检查参数是否为空
            if not name or not sex or not email or not phone or not addr or not xueli or not edu or not exper or not skill or not inten:
                print('输入的个人信息的值不能为空！')
                cur.close()
                conn.close()  # 关闭游标和数据库连接
                return
            sql3 = "INSERT INTO jobseeker (name, sex, email, phone, address, education, graduate_institutions, work_experience, skills, intention) " \
                  "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
            params = (name, sex, email, phone, addr, xueli, edu, exper, skill, inten)
            print("params ",params)
            print(sql3)
            cur.execute(sql3, params)
            print(cur.rowcount)
            if cur.rowcount == 1:
                print("插入成功")
            else:
                print("插入失败")
            # print(params)
            sql2 = "SELECT * FROM jobseeker WHERE name = %s"
            params2 = (name,)
            cur.execute(sql2, params2)
            data2 = cur.fetchone()
            print("data2 ",data2)

            # if data is None:
            #     print("未添加个人信息")
            #     cur.close()
            #     conn.close()
            #     return
            # else:
            #     print("个人信息已添加")
            #     QMessageBox.information(self, '添加信息', '个人信息已添加')


        cur.close()
        conn.close()

    def show_or_massage(self):
        print("show_or_massage clicked!")
        user, name = self.showchange_name(self.user)
        print(user, name)

        try:
            conn = pymysql.connect(host='localhost',
                                   user='root',
                                   password='123456',
                                   database='myhrms',
                                   charset='utf8')
            cur = conn.cursor()  # 生成游标对象
            sql = "SELECT * FROM jobseeker WHERE name = %s "
            params = (name)
            print("查询语句：", sql)
            print("查询参数：", params)
            cur.execute(sql, params)
            data = cur.fetchone()
            print("查询结果：data", data)
            email=data[3]
            tel=data[4]
            addr=data[5]
            xueli=data[6]
            educa=data[7]
            exper=data[8]
            skills=data[9]
            inten=data[10]

            if data:
                print(data)
                self.textEdit_3.setText(email)
                self.textEdit_10.setText(tel)
                self.textEdit_4.setText(addr)
                self.textEdit_5.setText(xueli)
                self.textEdit_6.setText(educa)
                self.textEdit_7.setText(exper)
                self.textEdit_8.setText(skills)
                self.textEdit_9.setText(inten)
            else:
                print("未添加个人信息")
                QMessageBox.warning(self, '提示', '请先添加个人信息')
        except Exception as e:
            print("查询出错：", e)
            QMessageBox.warning(self, '提示', '查询出错')
        finally:
            if cur:
                cur.close()
            if conn:
                conn.close()

    def update(self):
        if not self.user:
            print("用户未登录！")
            return

        user = self.user
        data = self.showchange_name(user)
        name=data[1]
        print("update clicked!")
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sex = self.afterClickButton()
        email = self.textEdit_3.toPlainText()
        phone = self.textEdit_10.toPlainText()
        addr = self.textEdit_4.toPlainText()
        xueli = self.textEdit_5.toPlainText()
        edu = self.textEdit_6.toPlainText()
        exper = self.textEdit_7.toPlainText()
        skill = self.textEdit_8.toPlainText()
        inten = self.textEdit_9.toPlainText()

        # 检查参数是否为空
        if not name or not sex or not email or not phone or not addr or not xueli or not edu or not exper or not skill or not inten:
            print('输入的值不能为空！')
            cur.close()
            conn.close()  # 关闭游标和数据库连接
            return
        # 定义更新语句和参数
        sql = "UPDATE jobseeker SET sex=%s, email=%s, phone=%s, address=%s, education=%s, graduate_institutions=%s, " \
              "work_experience=%s, skills=%s, intention=%s WHERE name=%s"
        params = (sex, email, phone, addr, xueli, edu, exper, skill, inten, name)
        try:
            # 执行更新操作
            cur.execute(sql, params)
            print("成功修改！")
            QMessageBox.information(self, '修改信息', '成功修改！')
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('修改失败：', e)
        finally:# 关闭游标和数据库连接
            cur.close()
            conn.close()

#删除个人简历信息代码------------------------------------------------------
class Del_seeker_Ui_Form(QMainWindow, del_seeker_Ui_Form):
    def __init__(self,user):
        super(Del_seeker_Ui_Form, self).__init__()
        self.user = user
        self.setupUi(self)
        self.pushButton.clicked.connect(self.delete)
        self.pushButton_2.clicked.connect(self.close)
        self.showdele_name(user)

    def Open(self):
        self.show()

    def showdele_name(self, user):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT job_seeker_name FROM `user_job_seekers` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        del_name=data[0]
        del_user_text = user
        del_name_text = del_name
        self.textBrowser.setText(del_name_text)
        self.textBrowser_2.setText(del_user_text)
        return user,del_name

    def delete(self,user):
        user,del_name=self.showdele_name(self.user)
        print("del clicked!")
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id from jobseeker where name = %s"  # 先找到要删除对象的id
        params = (del_name,)
        try:
            cur.execute(sql, params)
            data = cur.fetchone()  # 通过fetchone方法获得数据
            if not data:
                print('查询结果为空！')
                QMessageBox.warning(self, '警告', '查询结果为空！')
                return
            params2 = data[0]
            sql2 = "delete from jobseeker where id= %s"
            cur.execute(sql2, params2)
            print("成功删除简历信息！")
            # 提交事务
            conn.commit()

        except Exception as e:
            conn.rollback()
            print('删除简历信息失败：', e)
            QMessageBox.warning(self, '警告', '删除失败！')
        finally:
            cur.close()
            conn.close()
#检查简历状态功能---------------------------------------------------------------
class Check_cv_Ui_Form(QMainWindow,check_cv_Ui_Form):#查阅简历状态功能
    def __init__(self,user):
        super(Check_cv_Ui_Form,self).__init__()
        self.setupUi(self)
        self.user=user
        self.pushButton.clicked.connect(self.checkCV)
        self.pushButton_2.clicked.connect(self.close)
        self.print_my_info()

    def Open(self):
        self.show()
    def show_my_info(self,user):
        print("show_my_info")
        self.user = user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT job_seeker_name FROM `user_job_seekers` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        name=data[0]
        return user,name

    def print_my_info(self):
        print("print_my_info")
        user, name = self.show_my_info(self.user)#wangwu 王五
        print(user, name)#wangwu 王五
        self.label_2.setText(name)


    def checkCV(self):
        print("Button clicked")
        self.showCV()

    def showCV(self):
        print("Check_cv_Ui_Form showCV")
        user, name = self.show_my_info(self.user)  # wangwu 王五
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有3个属性
        self.tableWidget.setColumnCount(5)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(['序号', '姓名', '公司名称', '岗位名称', '岗位状态'])
        print(name)

        # 检查参数是否为空
        if not name:
            print('输入的名称不能为空！,请重新输入')
            # QMessageBox.warning(self, '输入的名称不能为空！')
            return

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        try:
            cur = conn.cursor()  # 生成游标对象
            sql = "select * from applications where name = %s"  # SQL语句
            params = (name,)
            cur.execute(sql, params)  # 执行SQL语句
            data = cur.fetchall()  # 通过fetchall方法获得数据

            x = 0
            for i in data:
                y = 0
                curRow = self.tableWidget.rowCount()  # 获取当前行
                self.tableWidget.insertRow(curRow)  # 插入一行
                for j in i:
                    self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                    y = y + 1
                x = x + 1

            print('查询成功！')

        except Exception as e:
            print('查询失败：', e)
            # QMessageBox.warning(self, '警告', '查询失败！', parent=self)

        finally:
            cur.close()  # 关闭游标
            conn.close()  # 关闭连接
#查询个人信息功能----------------------------------------------------------------
class My_cv_info(QMainWindow,my_cv_info_MainWindow):
    def __init__(self,user):
        super(My_cv_info, self).__init__()
        self.setupUi(self)
        self.user=user
        self.print_my_info()
        self.check_cv_jobseeker_win=None
        self.action.triggered.connect(self.Open_check_cv_jobseeker)

    def Open(self):
        self.show()

    def Open_check_cv_jobseeker(self,user):#打开查看简历状态子窗口
        if not self.check_cv_jobseeker_win:
            self.check_cv_jobseeker_win=Check_cv_Ui_Form(self.user)
        self.check_cv_jobseeker_win.Open()


    def show_my_info(self,user):
        print("show_my_info")
        self.user = user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT job_seeker_name FROM `user_job_seekers` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        name=data[0]
        return user,name
    def print_my_info(self):
        print("print_my_info")
        user, name = self.show_my_info(self.user)#wangwu 王五
        print(user, name)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT  email,work_experience, skills, intention FROM jobseeker WHERE name = %s"
        params1 = (name,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("data",data) #data ('wangwu@example.com', '有5年工作经验', 'Java, Spring', '架构师')
        email=data[0]
        exp=data[1]
        skill=data[2]
        inten=data[3]
        if data:#显示求职者简历基本信息
            self.label_7.setText(user)
            self.label_8.setText(name)
            self.label_9.setText(email)
            self.label_10.setText(exp)
            self.label_11.setText(skill)
            self.label_12.setText(inten)
        else:
            print("查询结果为空")
        cur.close()
        conn.close()


#简历投递功能----------------------------------------------------------------
class Re_deliver(QMainWindow,re_deliver_Ui_Form):#简历投递功能
    def __init__(self,user):
        super(Re_deliver, self).__init__()
        self.setupUi(self)
        self.user=user
        self.print_my_info()
        self.pushButton_2.clicked.connect(self.checkallcom)
        self.pushButton.clicked.connect(self.concompany)
        self.pushButton_3.clicked.connect(self.close)
        self.pushButton_4.clicked.connect(self.select_inten_company)

    def Open(self):
        self.show()

    def show_my_info(self,user):
        print("show_my_info")
        self.user = user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT job_seeker_name FROM `user_job_seekers` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        name=data[0]
        return user,name
    def print_my_info(self):
        print("print_my_info")
        user, name = self.show_my_info(self.user)#wangwu 王五
        print(user, name)
        self.label_5.setText(user)
        self.label_6.setText(name)

    def select_inten_company(self):
        print("select_inten_company")
        user, name = self.show_my_info(self.user)  # wangwu 王五
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        inten = self.textEdit_4.toPlainText()
        if not inten:
            print("输入的意向岗位不能为空！")
            QMessageBox.warning(self, '错误', '输入的意向岗位不能为空！')
            cur.close()
            conn.close()  # 关闭游标和数据库连接
            return

        sql1 = "SELECT  * FROM recruit WHERE position = %s"
        params1 = (inten)
        cur.execute(sql1, params1)
        data = cur.fetchall()  # 通过fetchall方法获得数据
        print("data",data)# (1, '经理', 'ABC公司', '北京市海淀区', '010-12345678', 20000, 5000)

        if data:
            # 重置
            self.tableWidget.setRowCount(0)
            # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
            self.tableWidget.setColumnCount(7)
            # 设置表头，这里为了演示，仅仅显示5列数据
            self.tableWidget.setHorizontalHeaderLabels(['HR-user', '岗位名称', '公司名称', '地址', '电话', '薪资', '人数'])
            x = 0
            for i in data:
                y = 0
                curRow = self.tableWidget.rowCount()  # 获取当前行
                self.tableWidget.insertRow(curRow)  # 插入一行
                for j in i:
                    self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                    y = y + 1
                x = x + 1

            cur.close()  # 关闭游标
            conn.close()  # 关闭连接


        else:
            print("暂无所查询的意向岗位")
            cur.close()  # 关闭游标
            conn.close()  # 关闭连接



    def showCompany(self):
        # 重置
        print("showRecruit clicked")
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(8)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(
            ['公司ID', '公司类型', '公司名称', '岗位名称', '岗位要求', '工作职责', '薪资', '工作地点'])

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select c_id, company_type,company, position,position_require,job_duty,money,job_place from recruit "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接

    def checkallcom(self):
        print("Check")
        self.showCompany()

    def concompany(self):
        # print("choose")
        self.chooseCompany()


    def chooseCompany(self):
        user, name = self.show_my_info(self.user)  # wangwu 王五
        try:
            print("chooseCompany update clicked!")
            conn = pymysql.connect(host='localhost',
                                   user='root',
                                   password='123456',
                                   database='myhrms',
                                   charset='utf8')
            cur = conn.cursor()  # 生成游标对象
            company_name = self.textEdit.toPlainText()
            # name = self.textEdit_2.toPlainText()
            intention = self.textEdit_3.toPlainText()
            print(company_name)
            print(intention)

            # 检查参数是否为空
            if not company_name or not intention:
                raise ValueError('输入的数据不能为空！请重新输入')

            # 查询公司和岗位是否存在
            sql1 = "select * from recruit where company = %s and position = %s"
            params1 = (company_name, intention)
            cur.execute(sql1, params1)
            result = cur.fetchone()
            if not result:
                raise ValueError('公司或岗位不存在，请重新输入！')

            # 查询是否已有申请记录
            sql3 = "select * from applications where name = %s and company = %s and position = %s"
            params3 = (name, company_name, intention)
            cur.execute(sql3, params3)
            result = cur.fetchone()
            if result:
                QMessageBox.warning(self, '错误', '投递失败： 已有申请记录，请勿重复投递！')
                raise ValueError('已有申请记录，请勿重复投递！')

            # 插入申请记录
            status = '0'
            sql2 = "INSERT INTO applications (name, company, position, resume_status) VALUES (%s, %s, %s, %s)"
            params2 = (name, company_name, intention, status)
            cur.execute(sql2, params2)
            conn.commit()
            print('成功投递！')
            QMessageBox.information(self, '投递信息', '成功投递！')

        except Exception as e:
            conn.rollback()
            print('投递失败：', e)
            QMessageBox.warning(self, '错误', '投递失败！')

        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()



if __name__ =="__main__":
    app = QApplication(sys.argv)
    # 创建窗口对象
    # user="chenA"
    #user="xiaohong"
    user="1010"
    main = Main(user)
    login=Login()
    login.show()
    #main.show()
    #main_object = demo.admin_Main()
    #dm = demo1.DemoUi(user)
    #dm.show()  # 出现界
    #main.show()
    #main_object.show()
    main.showcompany_se()
    sys.exit(app.exec_())
