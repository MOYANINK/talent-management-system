import sys
import pymysql
import hashlib
from PyQt5.QtWidgets import QMainWindow, QApplication, QAbstractItemView
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtWidgets import QTableWidgetItem
from mainwindows import Ui_MainWindow
from delwindows import Ui_DelWindow
from del_jobseeker_windows import Ui_DelJobWindow
from checkwindows import Ui_CheckWindow
from compwdwindows import Ui_compwdWindow
from jobpwdwindows import Ui_jobpwdWindow
from adminpwdwindows import Ui_adminpwdWindow
from addcomwiondows import Ui_addcompanyWindow
from addjobwindows import Ui_addjobWindow
from statisticswindows import Ui_statisticswindows
# from PyQt5 import QtCore, QtGui, QtWidgets

# 管理员主窗口
class admin_Main(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super(admin_Main, self).__init__()
        # 初始化窗口
        self.setupUi(self)
        # 某动作触发某事件
        self.showcompanyaction.triggered.connect(self.showcompany)  # 展示公司信息
        self.showjobseekeraction.triggered.connect(self.showjobseeker)  # 展示求职者信息
        self.showapplicationaction.triggered.connect(self.showapplication)  # 展示录用信息表
        self.showrecruitaction.triggered.connect(self.showrecruit)  # 展示招聘表
        self.adminaccaction.triggered.connect(self.showadminaccount)  # 展示管理员账号密码表
        self.comaccaction.triggered.connect(self.showcompanyaccount)  # 展示公司用户表
        self.jobaccaction.triggered.connect(self.showjobseekeraccount)  # 展示求职者用户表
        self.del_company_object = None  # 创建成员变量来保存 del_company_object 对象的引用
        self.delcomaccaction.triggered.connect(self.Open_del_company_object)  # 删除公司用户
        self.del_jobseeker_object = None
        self.deljobaccaction.triggered.connect(self.Open_del_jobseeker_object)  # 删除求职者用户
        self.check_object = None
        self.checkcompanyaction.triggered.connect(self.Open_check_object)  # 公司注册审核
        self.compwd_object = None
        self.compassaction.triggered.connect(self.Open_compwd_object)  # 更改公司用户密码
        self.jobpwd_object = None
        self.jobpassaction.triggered.connect(self.Open_jobpwd_object)  # 更改求职者用户密码
        self.adminpwd_object = None
        self.adminpassaction.triggered.connect(self.Open_adminpwd_object)  # 更改管理员密码
        self.addcom_object = None
        self.addcomaction.triggered.connect(self.Open_addcom_object)  # 注册公司新用户
        self.addjob_object = None
        self.addjobaction.triggered.connect(self.Open_addjob_object)  # 注册求职者新用户
        self.statistics_object = None
        self.statisticsButton.clicked.connect(self.Open_statistics_object)  # 统计成功就职人数
        self.statistics_job_object = None
        self.statisticsButton2.clicked.connect(self.Open_statistics_job_object)  # 统计求职者用户人数
        self.statistics_com_object = None
        self.statisticsButton3.clicked.connect(self.Open_statistics_com_object)  # 统计公司用户人数
        # 打开主界面时隐藏统计按钮-只在其发挥功能是显示
        self.statisticsButton.setHidden(True)
        self.statisticsButton2.setHidden(True)
        self.statisticsButton3.setHidden(True)

    # 调用类中的Open方法方法打开子窗口显示数据
    # 统计公司用户数量
    def Open_statistics_com_object(self):
        if not self.statistics_com_object:
            self.statistics_com_object = Statistics_com()  # 若不存在则实例化一个类对象
        self.statistics_com_object.Open()

    # 统计求职者用户数量
    def Open_statistics_job_object(self):
        if not self.statistics_job_object:
            self.statistics_job_object = Statistics_job()
        self.statistics_job_object.Open()

    # 统计成功就职人数
    def Open_statistics_object(self):
        if not self.statistics_object:
            self.statistics_object = Statistics()
        self.statistics_object.Open()

    # 注册求职者用户
    def Open_addjob_object(self):
        if not self.addjob_object:
            self.addjob_object = Addjob()
        self.addjob_object.Open()

    # 注册公司用户
    def Open_addcom_object(self):
        if not self.addcom_object:
            self.addcom_object = Addcom()
        self.addcom_object.Open()

    # 修改管理员密码
    def Open_adminpwd_object(self):
        if not self.adminpwd_object:
            self.adminpwd_object = Adminpwd()
        self.adminpwd_object.Open()

    # 修改求职者用户密码
    def Open_jobpwd_object(self):
        if not self.jobpwd_object:
            self.jobpwd_object = Jobpwd()
        self.jobpwd_object.Open()

    # 修改公司用户密码
    def Open_compwd_object(self):
        if not self.compwd_object:
            self.compwd_object = Compwd()
        self.compwd_object.Open()

    # 公司注册信息审核
    def Open_check_object(self):
        if not self.check_object:
            self.check_object = Check()
        self.check_object.Open()

    # 删除求职者用户
    def Open_del_jobseeker_object(self):
        if not self.del_jobseeker_object:
            self.del_jobseeker_object = Del_Job()
        self.del_jobseeker_object.Open()

    # 删除公司用户
    def Open_del_company_object(self):
        if not self.del_company_object:
            self.del_company_object = Del()
        self.del_company_object.Open()

    # 连接登录界面到管理员主界面的跳转
    def Open(self):
        self.show()


    # 查看公司信息表
    def showcompany(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showCompany()
    def showCompany(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(6)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['公司编号', '公司名称', '公司类型', '地址', '电话', '邮箱'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        # 连接数据库
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select c_id,c_name,c_type,work_addr,c_tele,c_email from com_infor "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        # 遍历数据 逐行逐列插入数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看求职者信息表
    def showjobseeker(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showJobseeker()
    def showJobseeker(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(11)
        # 设置表头，显示列
        self.tableWidget.setHorizontalHeaderLabels(
            ['编号', '姓名', '性别', '邮件', '电话', '地址', '学历', '毕业院校', '工作经验', '技能', '意向岗位'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,name,sex,email,phone,address,education,graduate_institutions,work_experience,skills,status," \
              "intention from jobseeker"
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # （x行y列）插入数据
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看录用信息
    def showapplication(self):
        print("Button clicked")
        self.statisticsButton.setHidden(False)  # 显示Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showApplication()
    def showApplication(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(4)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '姓名', '公司名称', '任职'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,name,company,position from applications where resume_status = 1"  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看管理员账号密码表
    def showadminaccount(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showAdminaccount()
    def showAdminaccount(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(4)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,username,password from admins "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                if y == 3:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看公司用户表
    def showcompanyaccount(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(False)  # 显示Button3
        self.showCompanyaccount()
    def showCompanyaccount(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '公司名称', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,company_name,username,password from user_hrs where status = 1 "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看求职者用户表
    def showjobseekeraccount(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(False)  # 显示Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showJobseekeraccount()
    def showJobseekeraccount(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '姓名', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,job_seeker_name,username,password from user_job_seekers "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


    # 查看招聘信息表
    def showrecruit(self):
        print("Button clicked")
        self.statisticsButton.setHidden(True)  # 隐藏Button
        self.statisticsButton2.setHidden(True)  # 隐藏Button2
        self.statisticsButton3.setHidden(True)  # 隐藏Button3
        self.showRecruit()
    def showRecruit(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(8)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(
            ['公司编号', '公司类型', '公司名称', '岗位名称', '岗位要求', '工作职责', '薪资', '工作地点'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select c_id, company_type,company, position,position_require,job_duty,money,job_place from recruit "
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 在x行y列插入数据
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接

#子窗口
# 删除公司用户
class Del(QMainWindow, Ui_DelWindow):
    def __init__(self):
        super(Del, self).__init__()
        self.setupUi(self)
        self.delcompanyButton.clicked.connect(self.delcompany)  # 按键连接 - 删除简历信息
        self.pushButton.clicked.connect(self.close)  # 关闭窗口
    # 打开子窗口的同时展示数据

    def Open(self):
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['公司ID', '公司类型', '公司名称', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,company_name,username,password from user_hrs where status = 1  "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def delcompany(self):
        print("Button clicked")
        self.Delcompany()

    def Delcompany(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        username = self.delcompanyText.toPlainText()
        print(username)

        # 异常处理——输入为空或账号不存在
        if not username:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params = username
            sql1 = "select id from user_hrs where username=%s"
            cur.execute(sql1, params)
            datas = cur.fetchone()
            if not datas:
                print('该用户不存在')
                QMessageBox.warning(self, '警告', '该用户不存在')
                return
            # 用左外连接关联相关表的数据 删除用户时一键删除数据信息
            sql = "delete user_hrs,com_infor,recruit from user_hrs left join com_infor on user_hrs.id=com_infor.c_id " \
                  "left join recruit on com_infor.c_id=recruit.c_id where user_hrs.username = %s"
            cur.execute(sql, params)
            print("成功删除！")
            QMessageBox.warning(self, '提示', '删除成功')
            conn.commit()  # 提交事务
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            cur.close()  # 关闭游标和数据库连接
            conn.close()


# 删除求职者用户
class Del_Job(QMainWindow, Ui_DelJobWindow):
    def __init__(self):
        super(Del_Job, self).__init__()
        self.setupUi(self)
        self.deljobseekerButton.clicked.connect(self.deljobseeker)  # 按键连接 - 删除简历信息
        self.overButton.clicked.connect(self.close)  # 关闭窗口按键

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['求职者ID', '类型', '姓名', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from user_job_seekers"
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # （某行某列）插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def deljobseeker(self):
        print("Button clicked")
        self.Deljobseeker()

    def Deljobseeker(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        username = self.deljobseekerText.toPlainText()
        print(username)
        # 做异常处理——输入为空或账号不存在
        if not username:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params1 = username
            sql1 = "select id from user_job_seekers where username=%s"
            cur.execute(sql1, params1)
            datas = cur.fetchone()
            if not datas:
                print('该用户不存在')
                QMessageBox.warning(self, '警告', '该用户不存在')
                return
            params = (username)
            # 左外连接一键删除
            sql = "delete jobseeker,user_job_seekers from jobseeker left join user_job_seekers on jobseeker.id = user_job_seekers.id where user_job_seekers.username = %s"
            cur.execute(sql, params)
            print("成功删除！")
            QMessageBox.warning(self, '提示', '删除成功')
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()


# 更改某公司用户密码
class Compwd(QMainWindow, Ui_compwdWindow):
    def __init__(self):
        super(Compwd, self).__init__()
        self.setupUi(self)
        self.cpmpwdButton.clicked.connect(self.companypassword)  # 按键连接 - 删除简历信息
        self.overButton.clicked.connect(self.close)  # 关闭窗口

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '公司名称', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,company_name,username,password from user_hrs where status = 1 "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # （某行某列）插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def companypassword(self):
        print("Button clicked")
        self.Companypassword()

    def Companypassword(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象

        username = self.comaccText.toPlainText()
        password = self.compwdText.toPlainText()
        print(username, password)
        # 做异常处理——输入为空或账号不存在
        if not username or not password:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params1 = username
            sql1 = "select id from user_hrs where username=%s"
            cur.execute(sql1, params1)
            datas = cur.fetchone()
            if not datas:
                print('该用户不存在')
                QMessageBox.warning(self, '警告', '该用户不存在')
                return
            # 创建一个md5对象
            md5 = hashlib.md5()
            # 更新要加密的内容
            md5.update(password.encode('utf-8'))
            # 获取加密后的十六进制字符串
            password_md5 = md5.hexdigest()
            params = (password_md5, username)
            sql = "update user_hrs set password=%s where username=%s"
            cur.execute(sql, params)
            print("密码修改成功！！")
            QMessageBox.warning(self, '提示', '修改成功')
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()


# 更改某求职者用户密码
class Jobpwd(QMainWindow, Ui_jobpwdWindow):
    def __init__(self):
        super(Jobpwd, self).__init__()
        self.setupUi(self)
        self.jobpwdButton.clicked.connect(self.jobseekerpassword)
        self.overButton.clicked.connect(self.close)  # 关闭窗口

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        # 设置表格的列数
        self.tableWidget.setColumnCount(5)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '姓名', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from user_job_seekers "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # （某行某列）插入数据
                if y == 4:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def jobseekerpassword(self):
        print("Button clicked")
        self.Jobseekerpassword()

    def Jobseekerpassword(self):

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象

        username = self.jobaccText.toPlainText()
        password = self.jobpwdText.toPlainText()
        print(username, password)
        # 做异常处理——输入为空或账号不存在
        if not username or not password:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params1 = username
            sql1 = "select id from user_job_seekers where username=%s"
            cur.execute(sql1, params1)
            datas = cur.fetchone()
            if not datas:
                print('该用户不存在')
                QMessageBox.warning(self, '警告', '该用户不存在')
                return
            # 创建一个md5对象
            md5 = hashlib.md5()
            # 更新要加密的内容
            md5.update(password.encode('utf-8'))
            # 获取加密后的十六进制字符串
            password_md5 = md5.hexdigest()
            params = (password_md5, username)
            sql = "update user_job_seekers set password=%s where username=%s"
            cur.execute(sql, params)
            print("密码修改成功！！")
            QMessageBox.warning(self, '提示', '修改成功')
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()


# 更改管理员密码
class Adminpwd(QMainWindow, Ui_adminpwdWindow):
    def __init__(self):
        super(Adminpwd, self).__init__()
        self.setupUi(self)
        self.adminpwdButton.clicked.connect(self.adminpassword)
        self.overButton.clicked.connect(self.close)  # 关闭窗口

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        # 设置表格的列数
        self.tableWidget.setColumnCount(4)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['ID', '类型', '用户名', '密码'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from admins "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # （某行某列）插入数据
                if y == 3:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def adminpassword(self):
        print("Button clicked")
        self.Adminpassword()

    def Adminpassword(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        username = self.adminaccText.toPlainText()
        password = self.adminpwdText.toPlainText()
        print(username, password)
        # 做异常处理——输入为空或账号不存在
        if not username or not password:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params1 = username
            sql1 = "select id from admins where username = %s"
            cur.execute(sql1, params1)
            datas = cur.fetchone()
            if not datas:
                print('该用户不存在')
                QMessageBox.warning(self, '警告', '该用户不存在')
                return
            # 创建一个md5对象
            md5 = hashlib.md5()
            # 更新要加密的内容
            md5.update(password.encode('utf-8'))
            # 获取加密后的十六进制字符串
            password_md5 = md5.hexdigest()
            params = (password_md5, username)
            sql = "update admins set password=%s where username=%s"
            cur.execute(sql, params)
            print("密码修改成功！！")
            QMessageBox.warning(self, '提示', '修改成功')
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()


# 公司注册申请审核
class Check(QMainWindow, Ui_CheckWindow):
    def __init__(self):
        super(Check, self).__init__()
        self.setupUi(self)
        self.closeButton.clicked.connect(self.close)  # 按键连接 - 删除简历信息
        self.agreeButton.clicked.connect(self.check)  # 按键连接 - 删除简历信息

    # 打开子窗口的同时展示申请信息
    def Open(self):
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(6)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['公司ID', '类型', '用户名', '密码', '公司名称', '注册状态'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select id,type,username,password,company_name,status from user_hrs where status = 0"  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        x = 0
        for i in data:
            y = 0
            self.tableWidget.insertRow(x)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                if y == 3:
                    self.tableWidget.setItem(x, y, QTableWidgetItem('**********'))
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接
        self.show()

    def check(self):
        print("Button clicked")
        self.Check()

    def Check(self):

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        company_name = self.plainTextEdit.toPlainText()
        print(company_name)
        if not company_name:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params = (company_name)
            sql3 = "select id from user_hrs where status = 0 and company_name = %s"
            cur.execute(sql3, params)
            datas = cur.fetchone()
            if not datas:
                print('查询结果为空！')
                QMessageBox.warning(self, '警告', '操作对象不存在')
                return
            sql = "update user_hrs SET status=1 where company_name = %s"
            cur.execute(sql, params)
            print("同意注册申请！")
            QMessageBox.warning(self, '提示', '操作成功')
            # 将注册后的公司的部分信息插入公司信息表中
            sql1 = "select id,company_name from user_hrs where company_name = %s"
            cur.execute(sql1, params)
            data = cur.fetchall()
            params1 = (data[0][0], data[0][1])  # 传入ID和公司名称
            sql2 = "insert into com_infor (c_id,c_name) values (%s,%s)"
            cur.execute(sql2, params1)
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('操作失败：', e)
        finally:
            # 关闭游标和数据库连接
            cur.close()
            conn.close()


# 新增用户-公司
class Addcom(QMainWindow, Ui_addcompanyWindow):
    def __init__(self):
        super(Addcom, self).__init__()
        self.setupUi(self)
        self.addcomButton.clicked.connect(self.addcomaccount)
        self.overButton.clicked.connect(self.close)

    def Open(self):
        self.show()

    def addcomaccount(self):
        print("Button clicked")
        self.Addcomaccount()

    def Addcomaccount(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        c_id = self.idtext.toPlainText()
        c_name = self.c_nametext.toPlainText()
        c_type = self.typetext.toPlainText()
        c_username = self.usernametext.toPlainText()
        c_password = self.passwordtext.toPlainText()
        c_status = self.statustext.toPlainText()
        print(c_id, c_type, c_username, c_password, c_name, c_status)
        print(type(c_status))
        if not c_id or not c_type or not c_username or not c_password or not c_name or not c_status:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        if c_status != '1' and c_status != '0':
            print("注册状态只能为0或1！")
            QMessageBox.warning(self, '警告', '注册状态只能为0或1')
            cur.close()
            conn.close()
            return
        try:
            params = (c_username, c_id)
            sql2 = "select company_name from user_hrs where status = 1 and username = %s or id = %s"
            cur.execute(sql2, params)
            datas = cur.fetchone()
            if datas:
                print('用户已存在！')
                QMessageBox.warning(self, '警告', '用户已存在')
                return
            # 创建一个md5对象
            md5 = hashlib.md5()
            # 更新要加密的内容
            md5.update(c_password.encode('utf-8'))
            # 获取加密后的十六进制字符串
            password_md5 = md5.hexdigest()
            params1 = (c_id, c_type, c_username, password_md5, c_name, c_status)
            sql = "insert into user_hrs values (%s,%s,%s,%s,%s,%s)"  # 向账号密码表插入新数据
            cur.execute(sql, params1)
            print("注册成功！")
            QMessageBox.warning(self, '提示', '添加成功')
            params2 = (c_id, c_name)
            if c_status == '1':
                sql1 = "insert into com_infor(c_id,c_name) values (%s,%s)"  # 向公司表插入新公司信息
                cur.execute(sql1, params2)
                # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('添加用户失败：', e)
        finally:
            cur.close()
            conn.close()


# 添加用户-求职者
class Addjob(QMainWindow, Ui_addjobWindow):
    def __init__(self):
        super(Addjob, self).__init__()
        self.setupUi(self)
        self.addjobButton.clicked.connect(self.addjobaccount)
        self.overButton.clicked.connect(self.close)

    def Open(self):
        self.show()

    def addjobaccount(self):
        print("Button clicked")
        self.Addjobaccount()

    def Addjobaccount(self):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        j_id = self.plainTextEdit.toPlainText()
        j_name = self.plainTextEdit_2.toPlainText()
        j_type = self.plainTextEdit_3.toPlainText()
        j_username = self.plainTextEdit_4.toPlainText()
        j_password = self.plainTextEdit_5.toPlainText()
        print(j_id, j_name, j_type, j_username, j_password)
        if not j_id or not j_type or not j_username or not j_password or not j_name:
            print("输入不能为空")
            QMessageBox.warning(self, '警告', '输入不能为空')
            cur.close()
            conn.close()
            return
        try:
            params = (j_username, j_id)
            sql2 = "select job_seeker_name from user_job_seekers where username = %s or id = %s"
            cur.execute(sql2, params)
            datas = cur.fetchone()
            print(datas)
            if datas:
                print('用户已存在！')
                QMessageBox.warning(self, '警告', '用户已存在')
                return
            # 创建一个md5对象
            md5 = hashlib.md5()
            # 更新要加密的内容
            md5.update(j_password.encode('utf-8'))
            # 获取加密后的十六进制字符串
            password_md5 = md5.hexdigest()
            params1 = (j_id, j_type, j_name, j_username, password_md5)
            sql = "insert into user_job_seekers values (%s,%s,%s,%s,%s)"  # 向账号密码表插入新数据
            cur.execute(sql, params1)
            print("注册成功！")
            QMessageBox.warning(self, '提示', '添加成功')
            params2 = (j_id, j_name)
            sql1 = "insert into jobseeker(id,name) values (%s,%s)"  # 向求职者信息表插入求职者部分新信息
            cur.execute(sql1, params2)
            # 提交事务
            conn.commit()
        except Exception as e:
            conn.rollback()
            print('添加用户失败：', e)
        finally:
            cur.close()
            conn.close()


# 统计通过该平台成功就职的总人数
class Statistics(QMainWindow, Ui_statisticswindows):
    def __init__(self):
        super(Statistics, self).__init__()
        self.setupUi(self)

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(1)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['成功就职人数'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select count(*) from applications where resume_status = 1"  # SQL语句 统计人数
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        # data中只有一个数据
        curRow = self.tableWidget.rowCount()  # 获取当前行
        self.tableWidget.insertRow(curRow)  # 插入一行
        self.tableWidget.setItem(0, 0, QTableWidgetItem(str(data[0][0])))  # 插入数据
        cur.close()
        conn.close()
        self.show()


# 统计该平台求职者总人数
class Statistics_job(QMainWindow, Ui_statisticswindows):
    def __init__(self):
        super(Statistics_job, self).__init__()
        self.setupUi(self)
        # self.overButton.clicked.connect(self.close)

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(1)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['用户人数'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select count(*) from user_job_seekers"  # SQL语句 统计人数
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        # data中只有一个数据
        curRow = self.tableWidget.rowCount()  # 获取当前行
        self.tableWidget.insertRow(curRow)  # 插入一行
        self.tableWidget.setItem(0, 0, QTableWidgetItem(str(data[0][0])))  # 插入数据
        cur.close()
        conn.close()
        self.show()


# 统计该平台公司总数
class Statistics_com(QMainWindow, Ui_statisticswindows):
    def __init__(self):
        super(Statistics_com, self).__init__()
        self.setupUi(self)

    def Open(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数
        self.tableWidget.setColumnCount(1)
        # 设置表头
        self.tableWidget.setHorizontalHeaderLabels(['用户人数'])
        # 设置不可编辑
        self.tableWidget.setEditTriggers(QAbstractItemView.NoEditTriggers)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select count(*) from user_hrs where status = 1"  # SQL语句 统计人数
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        # data中只有一个数据
        curRow = self.tableWidget.rowCount()  # 获取当前行
        self.tableWidget.insertRow(curRow)  # 插入一行
        self.tableWidget.setItem(0, 0, QTableWidgetItem(str(data[0][0])))  # 插入数据
        cur.close()
        conn.close()
        self.show()


if __name__ == "__main__":
    # 实例化类对象
    app = QApplication(sys.argv)
    main_object = admin_Main()
    # 展示主窗口
    main_object.show()
    # 防止窗口闪退
    sys.exit(app.exec_())
