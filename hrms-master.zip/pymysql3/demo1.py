import sys
from PyQt5.QtWidgets import *
from release import Ui_MainWindow
import pymysql  # 实现mysql连接
from checkCV_com import checkCV_com
from showapplication import showapplication
from releaseRecriut import releaseRecriut
from childdelete import childdelete
from updateRecruit import updateRecruit
from cominformation import cominformation
from statistics_result import statistics_result
from release_cominfor import release_cominfor

conn = pymysql.connect(host='localhost',
                       user='root',
                       password='123456',
                       database='myhrms',
                       charset='utf8')

# 新建类来继承UiForm，这样我们再更改界面后，不用再去修改我们写的逻辑
class DemoUi(QWidget, Ui_MainWindow):
    # 类的初始化
    def __init__(self, user):
        super(DemoUi, self).__init__()
        self.setupUi(self)
        self.user = user
        #self.showCompany()
        #self.show_showCompany_user(user)

        # 使用菜单
        self.check_CV = None
        self.show_application = None
        self.release_recriut = None
        self.child_delete = None
        self.update_recruit = None
        self.check_cominfo = None
        self.statistics_result=None
        self.release_comInfor_result=None

        self.action_5.triggered.connect(self.Open_check_CV)  # 连接菜单上“查询求职者简历”子窗口
        self.action_7.triggered.connect(self.Open_show_application)  # 连接菜单上“查询已投递简历”子窗口
        self.action_3.triggered.connect(self.Open_release_recriut)  # 连接菜单上“发布公司招聘信息”子窗口
        self.action_4.triggered.connect(self.Open_child_delete)  # 连接菜单上“删除公司招聘信息”子窗口
        self.action_8.triggered.connect(self.Open_update_recruit)  # 连接菜单上“修改公司招聘信息”子窗口
        self.action.triggered.connect(self.Open_check_cominfo)  # 连接菜单上“查询公司信息”子窗口
        self.action_2.triggered.connect(self.Open_statistics_result)  # 连接菜单上“查询统计结果”子窗口
        self.action_9.triggered.connect(self.Open_release_comInfor_result)  # 连接菜单上“发布公司基本信息”子窗口
        self.showcom_name(user)

    def Open(self):
        self.show()

    def Open_check_cominfo(self, user):  # 使用CheckComInfo()类
        if not self.check_cominfo:
            self.check_cominfo = CheckComInfo(self.user)
        self.check_cominfo.Open()

    def Open_check_CV(self):  # 使用CheckCV()类
        if not self.check_CV:
            self.check_CV = CheckCV()
        self.check_CV.Open()

    def Open_show_application(self, user):  # 使用ShowApplication()类
        if not self.show_application:
            self.show_application = ShowApplication(self.user)
        self.show_application.Open()

    def Open_release_recriut(self, user):  # 使用ReleaseRecriut()类
        if not self.release_recriut:
            self.release_recriut = ReleaseRecriut(self.user)
        self.release_recriut.Open()

    def Open_child_delete(self, user):  # 使用ChildDelete()类
        if not self.child_delete:
            self.child_delete = ChildDelete(self.user)
        self.child_delete.Open()

    def Open_update_recruit(self,user):  # 使用UpdateRecruit()类
        if not self.update_recruit:
            self.update_recruit = UpdateRecruit(self.user)
        self.update_recruit.Open()

    def Open_statistics_result(self, user):  # 使用StatisticsResult()类
        if not self.statistics_result:
            self.statistics_result = StatisticsResult(self.user)
        self.statistics_result.Open()

    def Open_release_comInfor_result(self, user):  # 使用Release_ComInfor()类
        if not self.release_comInfor_result:
            self.release_comInfor_result = Release_ComInfor(self.user)
        self.release_comInfor_result.Open()

    def showcom_name(self, user):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        #sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        sql1 = "SELECT * FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        #print("data",data)
        company_name=data[4]
        company_type=data[5]
        #self.textBrowser.setText(del_name_text)
        #self.textBrowser_2.setText(del_user_text)
        #print("showcom_name",user,company_name)
        return user,company_name,company_type


    # 展示自己公司招聘信息
    def showCompany(self):
        # 重置
        #self.user=user
        user, company,company_type = self.showcom_name(self.user)
        #print("showCompany")
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
        self.tableWidget.setColumnCount(8)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(
            ['公司编号', '企业类型', '公司名称', '岗位名称', '岗位要求', '工作职责', '薪资福利', '工作地点'])

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from recruit where company=%s "  # SQL语句
        params = (company)
        cur.execute(sql, params)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        #print(data)
        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接

    def showcompanyContents(self):  # 刷新展示表
        #print("showCompany clicked")
        self.showCompany()



#查询统计结果
class StatisticsResult(QMainWindow,statistics_result):
    def __init__(self, user):
        super(StatisticsResult, self).__init__()
        self.setupUi(self)
        self.user = user
        self.statistics()

    def Open(self):
        self.show()

    #统计共选了几个求职者的简历
    def showcom_name(self, user):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("data",data)
        company_name=data[0]
        print("showcom_name",user,company_name)
        return user,company_name


    def statistics(self):
        user, company = self.showcom_name(self.user)
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
        self.tableWidget.setColumnCount(1)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(['统计结果'])
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql="select count(*) from applications where resume_status='1' and company=%s"
        param=(company)
        cur.execute(sql,param)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        print(data)
        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


# 查询公司信息
class CheckComInfo(QMainWindow, cominformation):
    def __init__(self, user):
        super(CheckComInfo, self).__init__()
        self.setupUi(self)
        self.user = user
        self.showcominfo()

    def Open(self):
        self.show()

    def showcom_name(self, user):
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("data",data)
        company_name=data[0]
        print("showcom_name",user,company_name)
        return user,company_name


    # 展示公司信息表
    def showcominfo(self):
        user, company = self.showcom_name(self.user)
        print("showcominfo")
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
        self.tableWidget.setColumnCount(6)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(
            ['公司编号', '公司姓名', '企业类型', '工作地点', '电话', '邮箱'])

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        print(company)
        sql = "select * from com_infor where c_name=%s and c_id=%s"  # SQL语句
        param = (company,user)
        print(sql)
        cur.execute(sql, param)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        print("showcominfo,data",data)

        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


# 查询所有求职者简历子窗口
class CheckCV(QMainWindow, checkCV_com):
    def __init__(self):
        super(CheckCV, self).__init__()
        self.setupUi(self)
        self.showseeker()

    def Open(self):
        self.show()

    def showseeker(self):
        # 重置
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
        self.tableWidget.setColumnCount(11)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(
            ['编号', '姓名', '性别', '邮件', '电话', '地址', '学历', '毕业院校', '工作经验', '技能', '意向岗位'])

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from check_seeker "  # SQL语句
        cur.execute(sql)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据

        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


# 查询已投递的简历子窗口并选择要招聘的求职者
class ShowApplication(QMainWindow, showapplication):
    def __init__(self, user):
        super(ShowApplication, self).__init__()
        self.setupUi(self)
        self.user = user
        self.showapplication()
        self.pushButton.clicked.connect(self.select)

    def showcom_name(self, user):
        # 使用 user 参数
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("showcom_name data", data)
        company_name = data[0]
        print("showcom_name", user, "company_name", company_name)
        cur.close()
        conn.close()

        return user, company_name

    def Open(self):
        self.show()

    def showapplication(self):
        print("showapplication")
        user, company = self.showcom_name(self.user)
        if company is None:
            print(f"No company found for user '{self.user}'")
            return

        print("showapplication",user,company)
        self.tableWidget.setRowCount(0)
        # 设置表格的列数，仅显示其中5列数据，虽然产品表中有6个属性
        self.tableWidget.setColumnCount(5)
        # 设置表头，这里为了演示，仅仅显示5列数据
        self.tableWidget.setHorizontalHeaderLabels(
            ['编号', '姓名','公司', '职位', '简历状态'])
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql = "select * from applications where company=%s"  # SQL语句
        params = (company,)
        print(sql)
        print(params)
        cur.execute(sql, params)  # 执行SQL语句
        data = cur.fetchall()  # 通过fetchall方法获得数据
        print("data",data) #data ((5, '小明', '小红公司', '老师', '0'),)

        x = 0
        for i in data:
            y = 0
            curRow = self.tableWidget.rowCount()  # 获取当前行
            self.tableWidget.insertRow(curRow)  # 插入一行
            for j in i:
                self.tableWidget.setItem(x, y, QTableWidgetItem(str(data[x][y])))  # 插入数据
                y = y + 1
            x = x + 1

        cur.close()  # 关闭游标
        conn.close()  # 关闭连接

    def select(self):

        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象

        seeker_name = self.textEdit.toPlainText()  # 获取求职者姓名
        print(seeker_name)
        sql1 = "update applications set resume_status='1' where name=%s"
        params1 = (seeker_name)
        print(sql1)
        print(params1)
        cur.execute(sql1, params1)  # 执行SQL语句
        self.showapplication()  # 按下“确定”的同时刷新表格

        conn.commit()
        cur.close()  # 关闭游标
        conn.close()  # 关闭连接


# 发布公司招聘内容子窗口
class ReleaseRecriut(QMainWindow, releaseRecriut):
    def __init__(self, user):
        super(ReleaseRecriut, self).__init__()
        self.setupUi(self)
        self.user = user
        self.pushButton.clicked.connect(self.release)

    def Open(self):
        self.show()

    def showcom_name(self, user):
        # 使用 user 参数
        self.user=user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        #sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        sql1 = "SELECT * FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("showcom_name data", data)
        #company_name = data[0]
        company_name=data[4]
        company_type=data[5]
        print("showcom_name", user, "company_name", company_name,"company_type",company_type)
        cur.close()
        conn.close()

        return user, company_name,company_type
    # 插入招聘信息
    #user是1001
    def release(self):
        user, company ,company_type= self.showcom_name(self.user)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        print("user="+user)
        print(company)
        position_name = self.textEdit_4.toPlainText()  # 岗位名称
        position_require = self.textEdit_5.toPlainText()  # 岗位要求
        job_duty = self.textEdit_6.toPlainText()  # 工作职责
        money = self.textEdit_7.toPlainText()  # 薪资福利
        job_place = self.textEdit_8.toPlainText()  # 工作地点

        company_id=user
        # company_type=data[1]
        print("company_type="+company_type)
        #company_name=data[2]
        company_name=company

        if position_name and position_require and job_duty and money and job_place:
            sql = "INSERT INTO `recruit` (`c_id`, `company_type`, `company`, `position`, `position_require`, `job_duty`, `money`, `job_place`) VALUES" \
                  " (%s,%s,%s,%s,%s,%s,%s,%s)"
            params = (company_id, company_type, company_name, position_name,
                      position_require, job_duty, money, job_place)
            try:
                cur.execute(sql, params)  # 执行SQL语句
                data = cur.fetchone()
                print("release函数执行完毕")
                QMessageBox.information(self, '发布', '成功发布！请刷新页面！')
                conn.commit()
            except Exception as e:
                conn.rollback()  # 回滚事务
                QMessageBox.warning(self, '发布', '发布失败：{}'.format(str(e)))
            finally:
                cur.close()  # 关闭游标
                conn.close()  # 关闭连接
        else:
            QMessageBox.warning(self, '发布', '所有字段均不能为空！')


#发布公司基本信息
class Release_ComInfor(QMainWindow, release_cominfor):
    def __init__(self, user):
        super(Release_ComInfor, self).__init__()
        self.setupUi(self)
        self.user = user
        self.pushButton.clicked.connect(self.re_cominfor)
        self.is_released = False  # 添加标志位

    def Open(self):
        self.show()

    def showcom_infor(self, user):
        # 使用 user 参数
        self.user=user
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        #sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        sql1 = "SELECT * FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("showcom_infor data", data)
        #company_name = data[0]
        company_name=data[4]
        company_type=data[5]
        print("showcom_infor", user, "company_name", company_name,"company_type",company_type)
        cur.close()
        conn.close()
        print("第一次")
        return user, company_name,company_type

    def re_cominfor(self):
        if self.is_released:  # 检查是否已经发布过
            return
        self.is_released = True  # 设置标志位为已发布
        print("进入re_cominfor函数")
        user, company ,company_type= self.showcom_infor(self.user)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        print("user="+user)
        print("company="+company)
        company_place = self.textEdit.toPlainText()  # 公司地点
        company_tele = self.textEdit_2.toPlainText()  # 公司电话
        company_email = self.textEdit_3.toPlainText()  # 公司邮箱

        if company_place and company_tele and company_email:
            sql = "REPLACE INTO com_infor (`c_id`, `c_name`, `c_type`, `work_addr`, `c_tele`, `c_email`) VALUES" \
                  " (%s,%s,%s,%s,%s,%s)"
            params = (user, company, company_type, company_place,company_tele, company_email)
            try:
                cur.execute(sql, params)  # 执行SQL语句
                data = cur.fetchone()
                QMessageBox.information(self, '发布', '成功发布！')
                conn.commit()
            except Exception as e:
                conn.rollback()  # 回滚事务
                QMessageBox.warning(self, '发布', '发布失败：{}'.format(str(e)))
            finally:
                cur.close()  # 关闭游标
                conn.close()  # 关闭连接
        else:
            QMessageBox.warning(self, '发布', '所有字段均不能为空！')
# 删除公司招聘内容子窗口
class ChildDelete(QMainWindow, childdelete):
    def __init__(self, user):
        super(ChildDelete, self).__init__()
        self.setupUi(self)
        self.user = user
        self.pushButton.clicked.connect(self.delete)

    def Open(self):
        self.show()

    def showcom_name(self, user):
        # 使用 user 参数
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("showcom_name data", data)
        company_name = data[0]
        print("showcom_name", user, "company_name", company_name)

        cur.close()
        conn.close()

        return user, company_name

    def delete(self):
        user, company = self.showcom_name(self.user)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象

        position_name = self.textEdit_2.toPlainText()  # 岗位名称
        if position_name:  # 判断岗位名称是否为空
            sql = "delete from recruit where company=%s and position=%s"  # SQL语句
            params = (company, position_name)
            print(sql)
            print(params)
            cur.execute(sql, params)  # 执行SQL语句
            conn.commit()
            cur.close()  # 关闭游标
            conn.close()  # 关闭连接
            if cur.rowcount > 0:
                QMessageBox.information(self, '提示', '删除成功，请刷新页面')
            else:
                QMessageBox.warning(self, '错误', '删除失败！岗位不存在')
        else:
            QMessageBox.warning(self, '错误', '岗位名称不能为空！')


# 修改公司招聘内容
class UpdateRecruit(QMainWindow, updateRecruit):
    def __init__(self,user):
        super(UpdateRecruit, self).__init__()
        self.setupUi(self)
        self.user=user
        self.pushButton.clicked.connect(self.updateRecruit)
        self.updateRecruit()

    def Open(self):
        self.show()

    def showcom_name(self, user):
        # 使用 user 参数
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT company_name FROM `user_hrs` where username = %s"
        params1 = (user,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        print("showcom_name data", data)
        company_name = data[0]
        print("showcom_name", user, "company_name", company_name)

        cur.close()
        conn.close()

        return user, company_name

    # def updateRecruit(self):
    #     user, company = self.showcom_name(self.user)
    #
    #     conn = pymysql.connect(host='localhost',
    #                            user='root',
    #                            password='123456',
    #                            database='myhrms',
    #                            charset='utf8')
    #     cur = conn.cursor()  # 生成游标对象
    #     print(company)
    #     sql = "select * from com_infor where c_name=%s"  # SQL语句
    #     param = (company,)
    #     print(sql)
    #     cur.execute(sql, param)  # 执行SQL语句
    #     data = cur.fetchall()  # 通过fetchall方法获得数据
    #     print("updateRecruit,data",data) #updateRecruit,data (('5', '小红公司', '教育', '广西桂林市', '010-11111111', 'xiaohong@qq.com'),)
    #     print(data[0][0])
    #     c_id=data[0][0]
    #     com_type=data[0][2]
    #     self.label_9.setText(c_id)
    #     self.label_10.setText(com_type)
    #     self.label_11.setText(company)
    #
    #     position_name = self.textEdit_4.toPlainText()  # 岗位名称
    #     position_require = self.textEdit_5.toPlainText()  # 岗位要求
    #     job_duty = self.textEdit_6.toPlainText()  # 工作职责
    #     money = self.textEdit_7.toPlainText()  # 薪资福利
    #     job_place = self.textEdit_8.toPlainText()  # 工作地点
    #
    #     if position_name and position_require and job_duty and money and job_place:
    #         # 判断输入的关键信息是否为空
    #         sql = "UPDATE `recruit` SET `c_id`=%s, `company_type`=%s, `company`=%s, `position`=%s, `position_require`=%s, " \
    #               "`job_duty`=%s, `money`=%s, `job_place`=%s WHERE `company`=%s AND `position`=%s"
    #         params = (c_id, com_type, company, position_name, position_require, job_duty, money, job_place, company,
    #                   position_name)
    #         try:
    #             cur.execute(sql, params)  # 执行 SQL 语句
    #             conn.commit()
    #             QMessageBox.information(self, '修改', '成功修改！请刷新页面！')
    #         except Exception as e:
    #             conn.rollback()  # 回滚事务
    #             QMessageBox.warning(self, '修改', '修改失败：{}'.format(str(e)))
    #         finally:
    #             cur.close()  # 关闭游标
    #             conn.close()  # 关闭连接
    #     else:
    #         QMessageBox.warning(self, '修改', '岗位名称、岗位要求、工作职责、薪资福利和工作地点均不能为空！')

    def updateRecruit(self):
        user, company = self.showcom_name(self.user)
        conn = pymysql.connect(host='localhost',
                               user='root',
                               password='123456',
                               database='myhrms',
                               charset='utf8')
        cur = conn.cursor()  # 生成游标对象
        sql1 = "SELECT * FROM recruit where company = %s"
        params1 = (company,)
        cur.execute(sql1, params1)
        data = cur.fetchone()
        #company_id=data[0]
        company_id=user
        company_type=data[1]
        #company_name=data[2]
        company_name=company
        print("公司编号是"+company_id)
        print("公司类型是"+company_type)
        print("公司名称是"+company_name)

        position_name_old=self.textEdit.toPlainText()  # 旧的岗位名称
        position_name_new = self.textEdit_4.toPlainText()  # 新的岗位名称
        position_require = self.textEdit_5.toPlainText()  # 岗位要求
        job_duty = self.textEdit_6.toPlainText()  # 工作职责
        money = self.textEdit_7.toPlainText()  # 薪资福利
        job_place = self.textEdit_8.toPlainText()  # 工作地点

        if position_name_new and position_require and job_duty and money and job_place:
            # 判断输入的关键信息是否为空
            sql = "UPDATE `recruit` SET `c_id`=%s, `company_type`=%s, `company`=%s, `position`=%s, `position_require`=%s, " \
                  "`job_duty`=%s, `money`=%s, `job_place`=%s WHERE `company`=%s AND `position`=%s"
            params = (company_id, company_type, company_name, position_name_new, position_require, job_duty, money, job_place, company_name,
                      position_name_old)
            try:
                cur.execute(sql, params)  # 执行 SQL 语句
                conn.commit()
                QMessageBox.information(self, '修改', '成功修改！请刷新页面！')
            except Exception as e:
                conn.rollback()  # 回滚事务
                QMessageBox.warning(self, '修改', '修改失败：{}'.format(str(e)))
            finally:
                cur.close()  # 关闭游标
                conn.close()  # 关闭连接
        else:
            pass
            # QMessageBox.warning(self, '修改', '岗位名称、岗位要求、工作职责、薪资福利和工作地点均不能为空！')


# 此处是测试代码
if __name__ == "__main__":
    # 记得修改showapplication.py里的showCV按钮
    app = QApplication(sys.argv)
    #user = 'xiaohong'
    user = '1010'
    dm = DemoUi(user)

    dm.show()  # 出现界面
    #dm.show_showCompany_user(user)
    dm.showCompany()

    sys.exit(app.exec())
